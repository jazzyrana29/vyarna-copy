// nativewind.d.ts
import "nativewind/types";
