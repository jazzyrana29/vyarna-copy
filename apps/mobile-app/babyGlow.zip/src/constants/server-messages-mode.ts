export const ServerMessagesMode = {
  CONNECTION_ESTABLISHED: "connection-established",
  NEW_CONTACT_CREATED: "new-contact-created",
} as const;
