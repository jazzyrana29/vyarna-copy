// import "expo-dev-client"; // (only if you ejected with dev-client; otherwise omit)
import { registerRootComponent } from "expo";
import App from "./App";

registerRootComponent(App);
