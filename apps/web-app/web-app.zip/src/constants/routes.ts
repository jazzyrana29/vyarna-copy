export const NAV_ROUTE_HOME = "Vyarna Home" as const;
export const NAV_ROUTE_BENEFITS =
  "Vyarna - The Benefits of Breast Milk" as const;
export const NAV_ROUTE_USE = "How To Use Vyarna" as const;
export const NAV_ROUTE_IS_MADE = "How Vyarna Is Made" as const;
export const NAV_ROUTE_PARENTS = "Vyarna - For Parents" as const;
export const NAV_ROUTE_PROVIDERS = "Vyarna - For Providers" as const;
export const NAV_ROUTE_BIOHACKERS = "Vyarna - For Biohackers" as const;
export const NAV_ROUTE_VALUES = "Vyarna - Our Values" as const;
export const NAV_ROUTE_PREORDER = "Vyarna - Preorder" as const;
export const NAV_ROUTE_FAQ = "Vyarna - Frequently Asked Questions" as const;
export const NAV_ROUTE_INVESTORS = "Vyarna - For Investors" as const;
export const NAV_ROUTE_ABOUT = "Vyarna - About Us" as const;
export const NAV_ROUTE_CONTACT = "Vyarna - Contact" as const;
export const NAV_ROUTE_AUDIENCE = "audience" as const;
export const NAV_ROUTE_COMPANY = "company" as const;
export const NAV_ROUTE_SUPPORT = "support" as const;
export const NAV_ROUTE_PRODUCT = "product" as const;
