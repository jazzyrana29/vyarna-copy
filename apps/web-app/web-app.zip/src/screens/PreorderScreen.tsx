'use client';

import { type FC, useState } from 'react';
import { Image, ScrollView, Text, TouchableOpacity, View } from 'react-native';
import Email from '../components/Email';
import Footer from '../components/Footer';
import Section from '../components/Section';
import Cart from '../components/Cart';
import ProductSelector from '../components/ProductSelector';
import UserDetailsModal from '../components/UserDetailsModal';
import { useCartStore } from '../store/cartStore';
import { type UserDetails, useUserStore } from '../store/userStore';
import { TagsEnum } from '../enums/tags.enum';
import * as Animatable from 'react-native-animatable';

const PreorderScreen: FC = () => {
  const [productSelectorVisible, setProductSelectorVisible] = useState(false);
  const [userDetailsModalVisible, setUserDetailsModalVisible] = useState(false);
  const [isLoadingUserDetails, setIsLoadingUserDetails] = useState(false);

  const { isOpen, closeCart, getItemCount, getTotal, getTotalSavings } =
    useCartStore();
  const { userDetails, hasUserDetails, setUserDetails } = useUserStore();

  const handlePreorderClick = () => {
    if (!hasUserDetails()) {
      setUserDetailsModalVisible(true);
    } else {
      setProductSelectorVisible(true);
    }
  };

  const handleUserDetailsSubmit = async (details: UserDetails) => {
    setIsLoadingUserDetails(true);
    try {
      // Simulate processing time
      await new Promise((resolve) => setTimeout(resolve, 1000));

      setUserDetails(details);
      setUserDetailsModalVisible(false);
      setProductSelectorVisible(true);
    } catch (error) {
      console.error('Error saving user details:', error);
    } finally {
      setIsLoadingUserDetails(false);
    }
  };

  const handleBackToProducts = () => {
    setProductSelectorVisible(true);
  };

  return (
    <ScrollView className="flex-1 bg-white">
      <View className="max-w-screen-xl mx-auto px-4 py-8">
        {/* Hero */}
        <Animatable.View animation="fadeIn" delay={100}>
          <View className="relative w-full h-[500px] md:h-[600px] overflow-hidden rounded-lg shadow-sm">
            <Image
              source={require('../assets/images/preorder/preorder_hero.png')}
              style={{
                position: 'absolute',
                width: '100%',
                height: '100%',
                resizeMode: 'cover',
              }}
            />
            <View className="absolute inset-0 bg-gradient-to-b from-[#00000033] to-[#ffffff99]" />
            <View className="relative z-10 h-full flex flex-col items-center justify-center text-center px-4">
              <Text className="text-white text-3xl md:text-5xl font-bold leading-snug drop-shadow-lg max-w-2xl">
                Secure Your First Pack of Vyarna
              </Text>
              <Text className="text-white text-base md:text-lg mt-4 max-w-2xl drop-shadow-md">
                Limited early inventory. Verified providers. Real
                milk—reinvented.
              </Text>
              <TouchableOpacity
                className="bg-[#7ecaf8] px-6 py-3 rounded-full mt-6"
                onPress={handlePreorderClick}
              >
                <Text className="text-white font-bold text-base">
                  {hasUserDetails() ? 'Shop Now' : 'Get Started'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </Animatable.View>

        {/* Spacer */}
        <View className="h-16 md:h-20" />

        {/* User Status Display */}
        {hasUserDetails() && (
          <View className="mb-6 bg-green-50 px-4 py-3 rounded-lg">
            <Text className="text-green-800 font-semibold">
              Welcome back, {userDetails?.firstName}!
            </Text>
            <Text className="text-green-700 text-sm">
              Checking for presale discounts with {userDetails?.email}
            </Text>
          </View>
        )}

        {/* Cart Summary (if items in cart) */}
        {getItemCount() > 0 && (
          <View className="mb-12 bg-[#e8f4fd] px-6 py-4 rounded-xl shadow-sm">
            <View className="flex-row justify-between items-center">
              <View>
                <Text className="text-lg font-bold text-primary">
                  {getItemCount()} item(s) in cart
                </Text>
                <Text className="text-base text-neutralText">
                  Total: ${getTotal().toFixed(2)}
                </Text>
                {getTotalSavings() > 0 && (
                  <Text className="text-sm text-green-600">
                    You're saving ${getTotalSavings().toFixed(2)}!
                  </Text>
                )}
              </View>
              <TouchableOpacity
                className="bg-primary px-4 py-2 rounded-lg"
                onPress={() => useCartStore.getState().openCart()}
              >
                <Text className="text-white font-semibold">View Cart</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* What You Get */}
        <Section
          title="What's In the Box"
          text={`• 150 x 1g Vyarna Booster packets (One month supply!)\n• Individually sealed and shelf-stable\n• Mix into bottle, food, or spoon\n• Includes usage guide and baby-safe scoop`}
          image={require('../assets/images/preorder/box_contents.jpg')}
        />

        {/* Trust Section */}
        <View className="my-12 bg-[#f9fafb] py-4 md:py-6 rounded-lg shadow-sm">
          <Section
            reverse
            title="Verified Providers. Transparent Testing."
            text={`We work only with screened, compensated providers. Each batch is lab-tested, freeze-dried in our facility, and traceable to origin.\n\nWe're redefining trust in early nutrition.`}
            image={require('../assets/images/preorder/provider_trust.png')}
          />
        </View>

        {/* Value Section */}
        <Section
          title="More Than a Product — A New Standard"
          text={`Vyarna blends milk from diverse providers to concentrate immune and microbiome signals. It's real milk, made accessible.\n\nNo synthetics. No cold chain. Just powerful simplicity.`}
          image={require('../assets/images/preorder/value_proposition.png')}
        />

        {/* Final CTA */}
        <View className="text-center mb-12">
          <Text className="text-2xl font-bold text-[#d6336c] mb-2">
            Reserve Your Booster Pack
          </Text>
          <Text className="text-base text-neutral-700 mb-4 max-w-2xl mx-auto">
            We are producing limited launch inventory for 2026. Preorder now to
            lock your place—and your discount.
          </Text>
          <TouchableOpacity
            className="bg-[#7ecaf8] px-6 py-3 rounded-full"
            onPress={handlePreorderClick}
          >
            <Text className="text-white font-bold text-base">
              {hasUserDetails() ? 'Shop Now' : 'Start Your Order'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Email fallback CTA */}
        <View className="px-6 py-8 max-w-3xl mx-auto">
          <Email
            title="Not Ready Yet?"
            description="Leave your email and we'll let you know before we run out of early inventory."
            formId={TagsEnum.SIGNUP_PREORDER_BOTTOM}
          />
        </View>
      </View>

      {/* User Details Modal */}
      <UserDetailsModal
        visible={userDetailsModalVisible}
        onClose={() => setUserDetailsModalVisible(false)}
        onSubmit={handleUserDetailsSubmit}
        isLoading={isLoadingUserDetails}
      />

      {/* Product Selector Modal */}
      <ProductSelector
        visible={productSelectorVisible}
        onClose={() => setProductSelectorVisible(false)}
      />

      {/* Cart Modal */}
      <Cart
        visible={isOpen}
        onClose={closeCart}
        onBackToProducts={handleBackToProducts}
      />

      <Footer />
    </ScrollView>
  );
};

export default PreorderScreen;
