'use client';

import { useEffect, useState } from 'react';
import { wsService } from '../services/websocketService';
import { WS_MESSAGES } from '../constants/websocket-messages';
import { useUserStore } from '../store/userStore';
import { wsApiService } from '../services/websocketApiService';

export const useWebSocketConnection = () => {
  const [isConnected, setIsConnected] = useState(false);
  const [connectionError, setConnectionError] = useState<string | null>(null);

  const { userDetails } = useUserStore();

  useEffect(() => {
    const unsubConn = wsService.on(WS_MESSAGES.CONNECTION_ESTABLISHED, () => {
      setIsConnected(true);
      setConnectionError(null);
      console.log('WebSocket connected');
    });

    if (userDetails?.email) {
      wsApiService.joinCustomerRoom(userDetails.email);
    }

    return () => {
      unsubConn();
      if (userDetails?.email) {
        wsApiService.leaveCustomerRoom(userDetails.email);
      }
    };
  }, [userDetails?.email]);

  return { isConnected, connectionError };
};
