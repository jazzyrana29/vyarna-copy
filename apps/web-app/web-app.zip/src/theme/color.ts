// color.ts
export const colors = {
  primary: "#5AC8FA",
  secondary: "#9c9f9c",
  accent: "#FF6B6B",
  neutralText: "#272c31",
  background: "#F7F9FC",
  paper: "#c0bdbd",
};
